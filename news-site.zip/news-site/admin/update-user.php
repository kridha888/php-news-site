<?php include "header.php";
if($_SESSION["user_role"]=='0'){
    header("location:http://localhost/news-site/admin/post.php");
  }  

if(isset($_POST['submit'])){
$conn=mysqli_connect("localhost","root","","news-site","3307");

$userid=mysqli_real_escape_string($conn,$_POST['user_id']);
$fname=mysqli_real_escape_string($conn,$_POST['f_name']);
$lname=mysqli_real_escape_string($conn,$_POST['l_name']);
$user=mysqli_real_escape_string($conn,$_POST['username']);
$password=mysqli_real_escape_string($conn,$_POST['password']);
$role=mysqli_real_escape_string($conn,$_POST['role']);

$sql="UPDATE user SET first_name='{$fname}',last_name='{$lname}',username='{$user}',password='{$password}',role='{$role}' WHERE user_id={$userid}";
 
    if(mysqli_query($conn,$sql)){
        header("location:http://localhost/news-site/admin/users.php");
    }
}


?>


  <div id="admin-content">
      <div class="container">
          <div class="row">
              <div class="col-md-12">
                  <h1 class="admin-heading">Modify User Details</h1>
              </div>
              <div class="col-md-offset-4 col-md-4">
                <?php
                $ids=$_GET["id"];
                $conn=mysqli_connect("localhost","root","","news-site","3307");
                $sql="SELECT * FROM user WHERE user_id={$ids}";
                $result=mysqli_query($conn,$sql);
                if(mysqli_num_rows($result)>0){
                    while($row=mysqli_fetch_assoc($result)){
                ?>
                  <!-- Form Start -->
                  <form  action="" method ="POST">
                      <div class="form-group">
                          <input type="hidden" name="user_id"  class="form-control" value="<?php
                          echo $row['user_id'];?>" placeholder="" >
                      </div>
                          <div class="form-group">
                          <label>First Name</label>
                          <input type="text" name="f_name" class="form-control" value="<?php echo $row['first_name']?>">
                      </div>
                      <div class="form-group">
                          <label>Last Name</label>
                          <input type="text" name="l_name" class="form-control" value="<?php echo $row['last_name'];?>" placeholder="" required>
                      </div>
                      <div class="form-group">
                          <label>User Name</label>
                          <input type="text" name="username" class="form-control" value="<?php echo $row['username'];?>" placeholder="" required>
                      </div>

                      <div class="form-group">
                          <label>password</label>
                          <input type="text" name="password" class="form-control" value="<?php echo $row['password'];?>" placeholder="" required>
                      </div>


                      <div class="form-group">
                          <label>User Role</label>
                          <select class="form-control" name="role" value="<?php echo $row['role']; ?>">
                          <?php
                          if($row['role']==1){
                            echo "<option value=0>Normal user</option>
                            <option value=1>Admin</option>";
                          }else{echo "<option value=0>Normal user</option>
                            <option value=1>Admin</option>";
                          }
                          ?>
                          </select>
                      </div>
                      <input type="submit" name="submit" class="btn btn-primary" value="Update" required />
                  </form>
                  <!-- /Form -->
                  <?php
                    }
                }
                  ?>
              </div>
          </div>
      </div>
  </div>
<?php include "footer.php"; ?>
