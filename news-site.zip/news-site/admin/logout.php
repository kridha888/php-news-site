<?php
$conn=mysqli_connect("localhost","root","","news-site","3307");
session_start();
session_unset();
session_destroy();
header("location:http://localhost/news-site/admin/");
?>
