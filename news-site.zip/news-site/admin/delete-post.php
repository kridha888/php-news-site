<?php
$conn=mysqli_connect("localhost","root","","news-site","3307");
$post_id=$_GET['id'];
$cat_id=$_GET['catid'];
$sql="SELECT * FROM post WHERE post_id={$post_id}";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($result);
unlink("upload/".$row['post_img']);
$query1="DELETE FROM post WHERE post_id={$post_id}";
$query2="UPDATE category SET post=post-1 WHERE category_id={$cat_id}";
if(mysqli_query($conn,$query1)&&(mysqli_query($conn,$query2))){
    header("location:http://localhost/news-site/admin/users.php");
}else{
    echo "query failed";
}
?>