<?php
$conn=mysqli_connect("localhost","root","","news-site","3307") or die("query is not running properly");