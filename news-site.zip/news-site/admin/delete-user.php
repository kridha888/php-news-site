<?php
$conn=mysqli_connect("localhost","root","","news-site","3307");
if($_SESSION["user_role"]=='0'){
    header("location:http://localhost/news-site/admin/post.php");
  } 

$userids=$_GET['id'];
 echo $sql="DELETE FROM user WHERE user_id={$userids}";
if(mysqli_query($conn,$sql)){
    header("location:http://localhost/news-site/admin/users.php");
}
?>